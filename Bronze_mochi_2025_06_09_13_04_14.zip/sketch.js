let cloudX = 0;
let boatX = 0;

function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(135, 206, 250); // Céu azul

  // Desenhar nuvens
  drawCloud(cloudX, 100);
  drawCloud(cloudX + 200, 150);
  cloudX += 0.5;
  if (cloudX > width) cloudX = -200;

  // Desenhar campo
  drawField();

  // Desenhar cidade
  drawCity();

  // Desenhar ponte
  drawBridge();

  // Desenhar rio
  fill(30, 144, 255);
  rect(0, height - 150, width, 50);

  // Barco no rio
  drawBoat(boatX, height - 125);
  boatX += 1.2;
  if (boatX > width) boatX = -60;
}

function drawField() {
  // Solo verde
  fill(34, 139, 34);
  rect(0, height - 100, width / 2, 100);

  // Plantações (linhas verdes)
  stroke(0, 128, 0);
  for (let i = 50; i < width / 2; i += 30) {
    line(i, height - 100, i, height - 50);
  }

  // Árvore
  fill(139, 69, 19);
  rect(100, height - 180, 20, 60);
  fill(34, 139, 34);
  ellipse(110, height - 200, 60, 60);
}

function drawCity() {
  // Solo cinza
  fill(169, 169, 169);
  rect(width / 2, height - 100, width / 2, 100);

  // Prédios
  for (let i = width / 2 + 50; i < width; i += 100) {
    fill(150);
    let h = random(100, 110);
    rect(i, height - 100 - h, 60, h);
    fill(255, 255, 0);
    for (let j = height - 100 - h + 20; j < height - 100; j += 30) {
      rect(i + 10, j, 10, 10);
    }
  }
}

function drawBridge() {
  stroke(139, 69, 19);
  strokeWeight(8);
  line(width / 2 - 50, height - 150, width / 2 + 50, height - 150); // Ponte horizontal
  strokeWeight(3);
  for (let i = -50; i <= 50; i += 20) {
    line(width / 2 + i, height - 150, width / 2 + i, height - 170); // Pilares
  }
}

function drawBoat(x, y) {
  fill(255, 0, 0);
  rect(x, y, 60, 20);
  fill(255);
  triangle(x + 30, y - 20, x + 50, y, x + 10, y);
}

function drawCloud(x, y) {
  fill(255);
  noStroke();
  ellipse(x, y, 60, 40);
  ellipse(x + 30, y + 10, 50, 30);
  ellipse(x - 30, y + 10, 50, 30);
}